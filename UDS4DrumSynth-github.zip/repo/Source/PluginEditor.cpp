#include "PluginEditor.h"

namespace
{
    juce::String U (const char* utf8) { return juce::String (juce::CharPointer_UTF8 (utf8)); }

    const juce::Colour kBg      (0xff17191b);
    const juce::Colour kStrip   (0xff23262a);
    const juce::Colour kInk     (0xffd8d2c0);
    const juce::Colour kDim     (0xff8a8f94);
    const juce::Colour kAccent[] = { juce::Colour (0xffe8a33d),    // tone
                                     juce::Colour (0xff5ba3c7),    // noise
                                     juce::Colour (0xffd9534f),    // snap
                                     juce::Colour (0xffd8d2c0) };  // common

    // group: 0 tone, 1 noise, 2 snap, 3 common
    struct KnobDef { const char* id; const char* labUds; const char* cyrUds; const char* labEls; const char* cyrEls; bool uds, els; int group; };

    const KnobDef kKnobs[] = {
        { "sens",     "Sens",       "ЧУВСТВ.",   "Sens",       "ЧУВСТВ.",   true,  true,  3 },
        { "pitch",    "Tone",       "ТОН",       "Tone",       "ТОН",       true,  true,  0 },
        { "pAtk",     "Tone atk",   "АТАКА",     "",           "",          true,  false, 0 },
        { "tDecay",   "Tone rel",   "ЗАТУХАНИЕ", "Decay",      "ЗАТУХАНИЕ", true,  true,  0 },
        { "space",    "Space",      "СПЕЙС",     "Sweep",      "",          true,  true,  0 },
        { "spectrum", "Spectrum",   "СПЕКТР",    "",           "",          true,  false, 1 },
        { "timbre",   "Timbre",     "ТЕМБР",     "Filter",     "ФИЛЬТР",    true,  true,  1 },
        { "nAtk",     "Noise atk",  "АТАКА",     "Attack",     "ПОДХОД",    true,  true,  1 },
        { "nDecay",   "Noise rel",  "ЗАТУХАНИЕ", "",           "",          true,  false, 1 },
        { "balance",  "Balance",    "БАЛАНС",    "Tone/Noise", "ТОН/ШУМ",   true,  true,  3 },
        { "snap",     "Snap",       "ЩЕЛЧОК",    "",           "",          true,  false, 2 },
        { "snapTune", "Snap tune",  "",          "",           "",          true,  false, 2 },
        { "level",    "Level",      "УРОВЕНЬ",   "Level",      "УРОВЕНЬ",   true,  true,  3 },
    };
    constexpr int kNumKnobs = (int) (sizeof (kKnobs) / sizeof (kKnobs[0]));

    constexpr int kHeaderW = 150, kKnobW = 68, kStripH = 146, kMargin = 14, kTop = 58, kBottom = 70;

    juce::Font makeFont (float size, bool bold = false)
    {
        return juce::Font (juce::FontOptions (size, bold ? juce::Font::bold : juce::Font::plain));
    }
}

//==============================================================================
PanelLookAndFeel::PanelLookAndFeel()
{
    setColour (juce::Slider::textBoxTextColourId, kInk);
    setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    setColour (juce::Slider::textBoxBackgroundColourId, juce::Colours::transparentBlack);
    setColour (juce::ComboBox::backgroundColourId, juce::Colour (0xff111315));
    setColour (juce::ComboBox::textColourId, kInk);
    setColour (juce::ComboBox::outlineColourId, juce::Colour (0xff3a3f44));
    setColour (juce::ComboBox::arrowColourId, kDim);
    setColour (juce::PopupMenu::backgroundColourId, juce::Colour (0xff111315));
    setColour (juce::PopupMenu::textColourId, kInk);
    setColour (juce::ToggleButton::textColourId, kInk);
    setColour (juce::ToggleButton::tickColourId, kAccent[0]);
    setColour (juce::TextButton::buttonColourId, juce::Colour (0xff111315));
    setColour (juce::TextButton::textColourOffId, kInk);
}

void PanelLookAndFeel::drawRotarySlider (juce::Graphics& g, int x, int y, int w, int h, float pos,
                                         float startAngle, float endAngle, juce::Slider& s)
{
    const float alpha = s.isEnabled() ? 1.0f : 0.25f;
    auto bounds = juce::Rectangle<float> ((float) x, (float) y, (float) w, (float) h).reduced (4.0f);
    const float r = std::min (bounds.getWidth(), bounds.getHeight()) * 0.5f;
    const auto c = bounds.getCentre();
    const float ang = startAngle + pos * (endAngle - startAngle);
    const auto accent = s.findColour (juce::Slider::rotarySliderFillColourId).withMultipliedAlpha (alpha);

    juce::Path track;
    track.addCentredArc (c.x, c.y, r, r, 0.0f, startAngle, endAngle, true);
    g.setColour (juce::Colour (0xff3a3f44).withMultipliedAlpha (alpha));
    g.strokePath (track, juce::PathStrokeType (3.0f));

    juce::Path val;
    val.addCentredArc (c.x, c.y, r, r, 0.0f, startAngle, ang, true);
    g.setColour (accent);
    g.strokePath (val, juce::PathStrokeType (3.0f));

    const float br = r - 6.0f;
    g.setColour (juce::Colour (0xff0e1012).withMultipliedAlpha (alpha));
    g.fillEllipse (c.x - br, c.y - br, br * 2.0f, br * 2.0f);
    g.setColour (juce::Colour (0xff3f444a).withMultipliedAlpha (alpha));
    g.drawEllipse (c.x - br, c.y - br, br * 2.0f, br * 2.0f, 1.2f);

    juce::Path p;
    p.addRoundedRectangle (-1.6f, -br + 1.0f, 3.2f, br * 0.55f, 1.2f);
    g.setColour (accent);
    g.fillPath (p, juce::AffineTransform::rotation (ang).translated (c.x, c.y));
}

//==============================================================================
ChannelStrip::ChannelStrip (UDSProcessor& p, int channelIndex) : proc (p), index (channelIndex)
{
    modelBox.addItemList ({ "Lell UDS", "Elsita" }, 1);
    waveBox.addItemList ({ "Triangle", "Saw", "Pulse" }, 1);
    addAndMakeVisible (modelBox);
    addAndMakeVisible (waveBox);

    noteSlider.setSliderStyle (juce::Slider::IncDecButtons);
    noteSlider.setIncDecButtonsMode (juce::Slider::incDecButtonsNotDraggable);
    noteSlider.setTextBoxStyle (juce::Slider::TextBoxLeft, false, 70, 22);
    addAndMakeVisible (noteSlider);

    modelAttach = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (proc.apvts, UDSProcessor::pid (index, "model"), modelBox);
    waveAttach  = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (proc.apvts, UDSProcessor::pid (index, "wave"), waveBox);
    noteAttach  = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>   (proc.apvts, UDSProcessor::pid (index, "note"), noteSlider);

    for (int k = 0; k < kNumKnobs; ++k)
    {
        auto kn = std::make_unique<Knob>();
        kn->slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
        kn->slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, kKnobW - 2, 14);
        kn->slider.setColour (juce::Slider::rotarySliderFillColourId, kAccent[kKnobs[k].group]);
        addAndMakeVisible (kn->slider);
        kn->attach = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (proc.apvts, UDSProcessor::pid (index, kKnobs[k].id), kn->slider);
        knobs.push_back (std::move (kn));
    }

    modelBox.onChange = [this] { refreshModel(); };
    refreshModel();
}

void ChannelStrip::refreshModel()
{
    isElsita = proc.apvts.getRawParameterValue (UDSProcessor::pid (index, "model"))->load() > 0.5f;
    for (int k = 0; k < kNumKnobs; ++k)
    {
        const auto& d = kKnobs[k];
        auto& kn = *knobs[(size_t) k];
        const bool used = isElsita ? d.els : d.uds;
        kn.slider.setEnabled (used);
        kn.slider.setAlpha (used ? 1.0f : 0.3f);
        kn.label = isElsita ? d.labEls : d.labUds;
        kn.cyr   = isElsita ? U (d.cyrEls) : U (d.cyrUds);
        if (! used) kn.label = d.labUds;   // still show what it is, just dimmed
    }
    repaint();
}

void ChannelStrip::paint (juce::Graphics& g)
{
    auto b = getLocalBounds().toFloat();
    g.setColour (kStrip);
    g.fillRoundedRectangle (b, 8.0f);
    g.setColour (kAccent[(index % 2 == 0) ? 0 : 1].withAlpha (0.8f));   // A/B/A/B accent, as on the Elsita
    g.fillRoundedRectangle (b.removeFromLeft (5.0f), 2.0f);

    g.setColour (kInk);
    g.setFont (makeFont (30.0f, true));
    g.drawText (juce::String (index + 1), 18, 8, 40, 36, juce::Justification::centredLeft);
    g.setFont (makeFont (11.0f));
    g.setColour (kDim);
    g.drawText (isElsita ? U ("ЭЛСИТА") : U ("ЛЕЛЬ УДС"), 50, 14, 96, 24, juce::Justification::centredLeft);

    for (auto& kn : knobs)
    {
        auto la = kn->labelArea;   // copy: paint() must not consume the stored rectangle
        g.setColour (kn->slider.isEnabled() ? kInk : kDim.withAlpha (0.5f));
        g.setFont (makeFont (11.5f, true));
        g.drawText (kn->label, la.removeFromTop (14), juce::Justification::centred);
        g.setColour (kDim.withMultipliedAlpha (kn->slider.isEnabled() ? 1.0f : 0.5f));
        g.setFont (makeFont (9.5f));
        g.drawText (kn->cyr, la, juce::Justification::centredTop);
    }
}

void ChannelStrip::resized()
{
    auto area = getLocalBounds().reduced (6);
    auto head = area.removeFromLeft (kHeaderW - 6);
    head.removeFromTop (46);
    modelBox.setBounds (head.removeFromTop (24).reduced (6, 0));
    head.removeFromTop (6);
    waveBox.setBounds (head.removeFromTop (24).reduced (6, 0));
    head.removeFromTop (6);
    noteSlider.setBounds (head.removeFromTop (24).reduced (6, 0));

    for (int k = 0; k < kNumKnobs; ++k)
    {
        auto col = area.removeFromLeft (kKnobW);
        knobs[(size_t) k]->labelArea = col.removeFromTop (28);
        knobs[(size_t) k]->slider.setBounds (col);
    }
}

//==============================================================================
UDSEditor::UDSEditor (UDSProcessor& p) : juce::AudioProcessorEditor (&p)
{
    setLookAndFeel (&laf);
    for (int c = 0; c < uds::kNumChannels; ++c)
    {
        strips.push_back (std::make_unique<ChannelStrip> (p, c));
        addAndMakeVisible (*strips.back());
    }

    for (auto* s : { &driftSlider, &driveSlider, &masterSlider })
    {
        s->setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
        s->setTextBoxStyle (juce::Slider::TextBoxRight, false, 64, 18);
        s->setColour (juce::Slider::rotarySliderFillColourId, kAccent[3]);
        addAndMakeVisible (*s);
    }
    addAndMakeVisible (freeRunButton);
    driftA  = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (p.apvts, "drift", driftSlider);
    driveA  = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (p.apvts, "drive", driveSlider);
    masterA = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (p.apvts, "master", masterSlider);
    freeA   = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (p.apvts, "freeRun", freeRunButton);

    setSize (kHeaderW + kKnobW * kNumKnobs + kMargin * 2 + 12,
             kTop + (kStripH + 8) * uds::kNumChannels + kBottom);
}

UDSEditor::~UDSEditor() { setLookAndFeel (nullptr); }

void UDSEditor::paint (juce::Graphics& g)
{
    g.fillAll (kBg);
    g.setColour (kInk);
    g.setFont (makeFont (24.0f, true));
    g.drawText ("UDS-4", kMargin, 10, 140, 34, juce::Justification::centredLeft);
    g.setColour (kDim);
    g.setFont (makeFont (12.0f));
    g.drawText ("Drum synth inspired by the Lell UDS and RMIF Elsita. Not affiliated with either maker.",
                kMargin + 110, 10, getWidth() - 200, 34, juce::Justification::centredLeft);

    const int by = getHeight() - kBottom + 18;
    g.setColour (kInk);
    g.setFont (makeFont (11.5f, true));
    g.drawText ("Drift", kMargin + 4, by - 16, 60, 14, juce::Justification::centredLeft);
    g.drawText ("Drive", kMargin + 220, by - 16, 60, 14, juce::Justification::centredLeft);
    g.drawText ("Master", kMargin + 420, by - 16, 60, 14, juce::Justification::centredLeft);
}

void UDSEditor::resized()
{
    auto area = getLocalBounds().reduced (kMargin, 0);
    area.removeFromTop (kTop);
    for (auto& s : strips)
    {
        s->setBounds (area.removeFromTop (kStripH));
        area.removeFromTop (8);
    }
    const int by = getHeight() - kBottom + 4;
    driftSlider.setBounds  (kMargin,       by, 200, 48);
    driveSlider.setBounds  (kMargin + 216, by, 200, 48);
    masterSlider.setBounds (kMargin + 416, by, 200, 48);
    freeRunButton.setBounds (kMargin + 640, by + 10, 200, 28);
}
