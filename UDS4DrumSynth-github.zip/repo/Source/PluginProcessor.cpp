#include "PluginProcessor.h"
#include "PluginEditor.h"

namespace
{
    using Attr = juce::AudioParameterFloatAttributes;

    juce::String fmtHz (float v, int)  { return v >= 1000.0f ? juce::String (v / 1000.0f, 2) + " kHz" : juce::String (juce::roundToInt (v)) + " Hz"; }
    juce::String fmtMs (float v, int)  { return v >= 1000.0f ? juce::String (v / 1000.0f, 2) + " s" : (v >= 10.0f ? juce::String (juce::roundToInt (v)) + " ms" : juce::String (v, 1) + " ms"); }
    juce::String fmtPct (float v, int) { return juce::String (juce::roundToInt (v * 100.0f)) + " %"; }
    juce::String fmtX (float v, int)   { return "x" + juce::String (v, 2); }
    juce::String fmtDb (float v, int)  { return juce::String (v, 1) + " dB"; }
}

juce::AudioProcessorValueTreeState::ParameterLayout UDSProcessor::createLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;

    auto skewed = [] (float lo, float hi, float mid)
    {
        juce::NormalisableRange<float> r (lo, hi);
        r.setSkewForCentre (mid);
        return r;
    };

    for (int c = 0; c < uds::kNumChannels; ++c)
    {
        const auto d = uds::defaultChannel (c);
        const juce::String n = "Ch" + juce::String (c + 1) + " ";
        auto id = [&] (const char* s) { return juce::ParameterID { pid (c, s), 1 }; };

        layout.add (std::make_unique<juce::AudioParameterChoice> (id ("model"), n + "Model",
                        juce::StringArray { "Lell UDS", "Elsita" }, (int) d.model));
        layout.add (std::make_unique<juce::AudioParameterChoice> (id ("wave"), n + "Tone wave",
                        juce::StringArray { "Triangle", "Saw", "Pulse" }, (int) d.wave));
        layout.add (std::make_unique<juce::AudioParameterInt> (id ("note"), n + "MIDI note", 0, 127, uds::defaultNote (c),
                        juce::AudioParameterIntAttributes().withStringFromValueFunction ([] (int v, int)
                        { return juce::MidiMessage::getMidiNoteName (v, true, true, 3) + " (" + juce::String (v) + ")"; })));

        layout.add (std::make_unique<juce::AudioParameterFloat> (id ("sens"),     n + "Sensitivity", skewed (0.25f, 4.0f, 1.0f), d.sens, Attr().withStringFromValueFunction (fmtX)));
        layout.add (std::make_unique<juce::AudioParameterFloat> (id ("pitch"),    n + "Tone",        skewed (20.0f, 2000.0f, 150.0f), d.pitchHz, Attr().withStringFromValueFunction (fmtHz)));
        layout.add (std::make_unique<juce::AudioParameterFloat> (id ("pAtk"),     n + "Tone attack", skewed (0.1f, 150.0f, 5.0f), d.pAtkMs, Attr().withStringFromValueFunction (fmtMs)));
        layout.add (std::make_unique<juce::AudioParameterFloat> (id ("tDecay"),   n + "Tone release", skewed (5.0f, 6000.0f, 300.0f), d.tDecayMs, Attr().withStringFromValueFunction (fmtMs)));
        layout.add (std::make_unique<juce::AudioParameterFloat> (id ("space"),    n + "Space",       juce::NormalisableRange<float> (0.0f, 1.0f), d.space, Attr().withStringFromValueFunction (fmtPct)));
        layout.add (std::make_unique<juce::AudioParameterFloat> (id ("spectrum"), n + "Noise spectrum", skewed (200.0f, 60000.0f, 6000.0f), d.spectrumHz, Attr().withStringFromValueFunction (fmtHz)));
        layout.add (std::make_unique<juce::AudioParameterFloat> (id ("timbre"),   n + "Timbre / Filter", skewed (120.0f, 10000.0f, 1500.0f), d.timbreHz, Attr().withStringFromValueFunction (fmtHz)));
        layout.add (std::make_unique<juce::AudioParameterFloat> (id ("nAtk"),     n + "Noise attack", skewed (0.1f, 200.0f, 6.0f), d.nAtkMs, Attr().withStringFromValueFunction (fmtMs)));
        layout.add (std::make_unique<juce::AudioParameterFloat> (id ("nDecay"),   n + "Noise release", skewed (5.0f, 6000.0f, 250.0f), d.nDecayMs, Attr().withStringFromValueFunction (fmtMs)));
        layout.add (std::make_unique<juce::AudioParameterFloat> (id ("balance"),  n + "Balance",     juce::NormalisableRange<float> (0.0f, 1.0f), d.balance, Attr().withStringFromValueFunction (fmtPct)));
        layout.add (std::make_unique<juce::AudioParameterFloat> (id ("snap"),     n + "Snap",        juce::NormalisableRange<float> (0.0f, 1.0f), d.snap, Attr().withStringFromValueFunction (fmtPct)));
        layout.add (std::make_unique<juce::AudioParameterFloat> (id ("snapTune"), n + "Snap tune",   skewed (600.0f, 6000.0f, 2000.0f), d.snapTuneHz, Attr().withStringFromValueFunction (fmtHz)));
        layout.add (std::make_unique<juce::AudioParameterFloat> (id ("level"),    n + "Level",       juce::NormalisableRange<float> (0.0f, 1.0f), d.level, Attr().withStringFromValueFunction (fmtPct)));
    }

    const uds::Globals g;
    layout.add (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { "drift", 1 }, "Drift", juce::NormalisableRange<float> (0.0f, 1.0f), g.drift, Attr().withStringFromValueFunction (fmtPct)));
    layout.add (std::make_unique<juce::AudioParameterBool>  (juce::ParameterID { "freeRun", 1 }, "Free-running VCO", g.freeRun));
    layout.add (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { "drive", 1 }, "Output drive", juce::NormalisableRange<float> (0.0f, 1.0f), 0.1f, Attr().withStringFromValueFunction (fmtPct)));
    layout.add (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { "master", 1 }, "Master", juce::NormalisableRange<float> (-24.0f, 6.0f), 0.0f, Attr().withStringFromValueFunction (fmtDb)));
    return layout;
}

UDSProcessor::UDSProcessor()
    : AudioProcessor (BusesProperties().withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "UDS4", createLayout())
{
    for (int c = 0; c < uds::kNumChannels; ++c)
    {
        auto get = [&] (const char* s) { return apvts.getRawParameterValue (pid (c, s)); };
        ptrs[c] = { get ("model"), get ("wave"), get ("note"), get ("sens"), get ("pitch"), get ("pAtk"), get ("tDecay"),
                    get ("space"), get ("spectrum"), get ("timbre"), get ("nAtk"), get ("nDecay"), get ("balance"),
                    get ("snap"), get ("snapTune"), get ("level") };
    }
    pDrift  = apvts.getRawParameterValue ("drift");
    pFree   = apvts.getRawParameterValue ("freeRun");
    pMaster = apvts.getRawParameterValue ("master");
    pDrive  = apvts.getRawParameterValue ("drive");
}

uds::ChannelParams UDSProcessor::readParams (int c) const
{
    const auto& p = ptrs[c];
    uds::ChannelParams o;
    o.model      = p.model->load() > 0.5f ? uds::Model::Elsita : uds::Model::UDS;
    o.wave       = (uds::Wave) juce::jlimit (0, 2, (int) std::lround (p.wave->load()));
    o.sens       = p.sens->load();
    o.pitchHz    = p.pitch->load();
    o.pAtkMs     = p.pAtk->load();
    o.tDecayMs   = p.tDecay->load();
    o.space      = p.space->load();
    o.spectrumHz = p.spectrum->load();
    o.timbreHz   = p.timbre->load();
    o.nAtkMs     = p.nAtk->load();
    o.nDecayMs   = p.nDecay->load();
    o.balance    = p.balance->load();
    o.snap       = p.snap->load();
    o.snapTuneHz = p.snapTune->load();
    o.level      = p.level->load();
    return o;
}

void UDSProcessor::prepareToPlay (double sampleRate, int)
{
    for (int c = 0; c < uds::kNumChannels; ++c)
        channels[c].prepare (sampleRate, (uint32_t) (c + 1) * 7919u);
}

bool UDSProcessor::isBusesLayoutSupported (const BusesLayout& l) const
{
    return l.getMainOutputChannelSet() == juce::AudioChannelSet::stereo()
        || l.getMainOutputChannelSet() == juce::AudioChannelSet::mono();
}

void UDSProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    buffer.clear();

    uds::Globals g;
    g.drift   = pDrift->load();
    g.freeRun = pFree->load() > 0.5f;

    int notes[uds::kNumChannels];
    for (int c = 0; c < uds::kNumChannels; ++c)
    {
        channels[c].setParams (readParams (c), g);
        notes[c] = (int) std::lround (ptrs[c].note->load());
    }

    const float master = juce::Decibels::decibelsToGain (pMaster->load());
    const float drive  = pDrive->load();

    const int n = buffer.getNumSamples();
    float* L = buffer.getWritePointer (0);
    float* R = buffer.getNumChannels() > 1 ? buffer.getWritePointer (1) : nullptr;

    auto it = midi.begin();
    const auto end = midi.end();

    for (int i = 0; i < n; ++i)
    {
        while (it != end && (*it).samplePosition <= i)
        {
            const auto msg = (*it).getMessage();
            if (msg.isNoteOn())
            {
                for (int c = 0; c < uds::kNumChannels; ++c)
                    if (msg.getNoteNumber() == notes[c])
                        channels[c].trigger (msg.getFloatVelocity());
            }
            else if (msg.isAllNotesOff() || msg.isAllSoundOff())
            {
                for (auto& ch : channels) ch.reset();
            }
            ++it;
        }

        float s = 0.0f;
        for (auto& ch : channels) s += ch.process();

        const float y = uds::outputStage (s * master, drive);
        L[i] = y;
        if (R != nullptr) R[i] = y;
    }
}

void UDSProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    if (auto xml = apvts.copyState().createXml())
        copyXmlToBinary (*xml, dest);
}

void UDSProcessor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
        if (xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessorEditor* UDSProcessor::createEditor() { return new UDSEditor (*this); }

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new UDSProcessor(); }
