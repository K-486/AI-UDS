// UDSEngine.h - drum voice engine inspired by the Lell UDS and RMIF Elsita.
// Pure C++17, no JUCE dependency, so it can be unit-tested and rendered offline.
//
// LELL UDS model is built from sx107's schematic teardown (hackaday.io/project/171677):
//   * pad signal -> preamp -> positive-peak detector (diode charge, RC discharge)
//     => every envelope is VELOCITY SENSITIVE (level, pitch depth and decay length)
//   * tone: free-running relaxation VCO, triangle out, control LINEAR in Hz
//     (not 1V/oct). Pitch envelope = same decay as the tone VCA, but with its own
//     attack RC ("tone attack" shapes the pitch rise, amplitude attack is ~instant)
//   * noise: 18-bit shift-register LFSR whose clock is the "spectrum" knob,
//     then a bandpass ("timbre"), then a VCA with its own attack/decay
//   * snap: raw noise burst (very short env) + a hugely resonant filter that rings
//     a decaying sine when the pad pulse hits it
//   * tone/noise crossfade ("balance"), snap level, channel level, inverting mixer
//
// ELSITA model is built from the documented panel only (sensitivity, tone, attack,
// decay, filter, tone/noise, level); its schematic was not readable, so the internal
// structure is a conventional Simmons-lineage osc+noise -> filter -> VCA voice.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>

namespace uds
{
constexpr float kPi = 3.14159265358979323846f;

inline float clampf (float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

//==============================================================================
struct Rng
{
    uint32_t s = 0x1234567u;
    void seed (uint32_t v) { s = v ? v : 0x1234567u; }
    uint32_t nextU() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
    float next() { return (float) (int32_t) nextU() * (1.0f / 2147483648.0f); } // [-1,1)
};

struct OnePole
{
    float a = 1.0f, z = 0.0f;
    void setTime (float ms, float sr)
    {
        const float tau = std::max (ms, 0.01f) * 0.001f;
        a = 1.0f - std::exp (-1.0f / (tau * sr));
    }
    float process (float x) { z += a * (x - z); return z; }
    void reset (float v = 0.0f) { z = v; }
};

// Cytomic/Simper TPT state-variable filter. bp has unity peak gain.
struct Svf
{
    float k = 1.0f, a1 = 0, a2 = 0, a3 = 0, ic1 = 0, ic2 = 0;
    struct Out { float lp, bp; };
    void set (float fc, float q, float sr)
    {
        fc = clampf (fc, 10.0f, 0.45f * sr);
        const float g = std::tan (kPi * fc / sr);
        k = 1.0f / q;
        a1 = 1.0f / (1.0f + g * (g + k));
        a2 = g * a1;
        a3 = g * a2;
    }
    Out process (float x)
    {
        const float v3 = x - ic2;
        const float v1 = a1 * ic1 + a2 * v3;
        const float v2 = ic2 + a2 * ic1 + a3 * v3;
        ic1 = 2.0f * v1 - ic1;
        ic2 = 2.0f * v2 - ic2;
        return { v2, k * v1 };
    }
    void reset() { ic1 = ic2 = 0.0f; }
};

// 18-bit Fibonacci LFSR, taps 18 & 11 (x^18 + x^11 + 1, maximal length).
// The real unit XORs the last two outputs of a CD4006-type register; I could not
// verify which stages, so a maximal-length pair is used.
struct Lfsr
{
    uint32_t reg = 0x2AAAAu;
    double ph = 0.0;
    float out = 1.0f;
    void step()
    {
        const uint32_t bit = ((reg >> 17) ^ (reg >> 10)) & 1u;
        reg = ((reg << 1) | bit) & 0x3FFFFu;
        out = (reg & 1u) ? 1.0f : -1.0f;
    }
    float tick (double clocksPerSample)
    {
        ph += clocksPerSample;
        while (ph >= 1.0) { ph -= 1.0; step(); }
        return out;
    }
};

// Peak-detector envelope: the cap charges instantly through a diode (only if the
// new peak is higher than what is already stored) and discharges through an RC
// toward a level BELOW the VCA cutoff, so tails end cleanly instead of fading
// forever. `ms` is the time to reach zero from a full-level hit. Softer hits are
// therefore shorter as well as quieter, like the hardware.
struct RcEnv
{
    static constexpr float kFloor = 0.15f;
    float x = 0.0f, coef = 0.0f;
    void setTime (float ms, float sr)
    {
        const float T = std::max (ms, 1.0f) * 0.001f;
        const float tau = T / std::log ((1.0f + kFloor) / kFloor);
        coef = std::exp (-1.0f / (tau * sr));
    }
    void charge (float peak) { if (peak > x) x = peak; }
    float tick()
    {
        x = coef * x - (1.0f - coef) * kFloor;
        if (x < -kFloor) x = -kFloor;
        return x > 0.0f ? x : 0.0f;
    }
};

//==============================================================================
enum class Model { UDS = 0, Elsita = 1 };
enum class Wave  { Triangle = 0, Saw = 1, Pulse = 2 };

struct ChannelParams
{
    Model model = Model::UDS;
    Wave  wave  = Wave::Triangle;
    float sens       = 1.0f;     // pad sensitivity: velocity gain before the peak detector
    float pitchHz    = 100.0f;   // "tone"
    float pAtkMs     = 0.1f;     // UDS: pitch-envelope attack ("tone attack")
    float tDecayMs   = 300.0f;   // UDS: tone release.  Elsita: decay (shared)
    float space      = 0.0f;     // 0..1 pitch-envelope depth ("space"); Elsita: sweep
    float spectrumHz = 6000.0f;  // UDS: noise LFSR clock ("spektr")
    float timbreHz   = 1500.0f;  // UDS: noise bandpass ("timbre").  Elsita: filter cutoff
    float nAtkMs     = 0.5f;     // UDS: noise attack.  Elsita: amplitude attack
    float nDecayMs   = 200.0f;   // UDS: noise release
    float balance    = 0.5f;     // tone <-> noise
    float snap       = 0.0f;     // UDS: "shchelchok" level
    float snapTuneHz = 1900.0f;  // UDS: snap resonator tuning (trimmer on the real board)
    float level      = 0.8f;
};

struct Globals
{
    float drift   = 0.35f;   // VCO instability, 0..1
    bool  freeRun = true;    // VCO phase keeps running between hits, as on hardware
};

inline float spaceToHz (float space) { return 1200.0f * space * space; }

inline float oscSample (Wave w, float ph, float dt)
{
    auto blep = [] (float t, float d)
    {
        if (t < d)        { t /= d;               return t + t - t * t - 1.0f; }
        if (t > 1.0f - d) { t = (t - 1.0f) / d;   return t * t + t + t + 1.0f; }
        return 0.0f;
    };
    switch (w)
    {
        case Wave::Triangle: return 4.0f * std::fabs (ph - 0.5f) - 1.0f;
        case Wave::Saw:      return (2.0f * ph - 1.0f) - blep (ph, dt);
        case Wave::Pulse:
        {
            float v = ph < 0.5f ? 1.0f : -1.0f;
            v += blep (ph, dt);
            float p2 = ph + 0.5f; if (p2 >= 1.0f) p2 -= 1.0f;
            v -= blep (p2, dt);
            return v;
        }
    }
    return 0.0f;
}

//==============================================================================
class Channel
{
public:
    void prepare (double sampleRate, uint32_t seed)
    {
        sr = (float) sampleRate;
        rng.seed (seed * 2654435761u + 1u);
        lfsr.reg = 0x2AAAAu ^ (seed * 977u & 0x3FFFFu); if (! lfsr.reg) lfsr.reg = 1;
        wander.setTime (1500.0f, sr);
        const float a = wander.a;
        wanderGain = 1.0f / (0.577f * std::sqrt (a / (2.0f - a)));  // normalise to ~unit std
        toneAtk.setTime (0.2f, sr);
        snapEnv.setTime (10.0f, sr);
        reset();
    }

    void reset()
    {
        toneEnv.x = noiseEnv.x = snapEnv.x = 0.0f;
        pitchLag.reset(); noiseAtk.reset(); toneAtk.reset();
        noiseBp.reset(); elsFilter.reset();
        ry1 = ry2 = rImpulse = 0.0f;
        lastTimbre = -1.0f;
        idle = true;
    }

    // Call once per block (cheap) and before trigger().
    void setParams (const ChannelParams& np, const Globals& ng)
    {
        P = np; G = ng;
        toneEnv.setTime (P.tDecayMs, sr);
        noiseEnv.setTime (P.model == Model::UDS ? P.nDecayMs : P.tDecayMs, sr);
        pitchLag.setTime (P.pAtkMs, sr);
        noiseAtk.setTime (P.nAtkMs, sr);
        if (P.model == Model::UDS && std::fabs (P.timbreHz - lastTimbre) > 1e-3f)
        {
            noiseBp.set (P.timbreHz, kBpQ, sr);
            bpGain = std::min (12.0f, 0.35f * std::sqrt (sr * kBpQ / (kPi * P.timbreHz)));
            lastTimbre = P.timbreHz;
        }
    }

    void trigger (float velocity)
    {
        const float peak = clampf (velocity * P.sens, 0.0f, 1.0f);
        if (peak <= 0.0f) return;
        if (idle) { noiseBp.reset(); elsFilter.reset(); ry1 = ry2 = 0.0f; pitchLag.reset(); noiseAtk.reset(); toneAtk.reset(); idle = false; }

        toneEnv.charge (peak);
        noiseEnv.charge (peak);
        snapEnv.charge (peak);

        // snap resonator: excited by the (high-passed) pad pulse
        const float w = 2.0f * kPi * clampf (P.snapTuneHz, 100.0f, 0.45f * sr) / sr;
        const float r = std::exp (-1.0f / (sr * 0.004f));
        ra1 = 2.0f * r * std::cos (w);
        ra2 = -r * r;
        rb  = std::sin (w);
        rImpulse = peak;

        if (! G.freeRun) phase = 0.0f;
        hitCents = G.drift * 5.0f * rng.next();
    }

    bool isActive() const { return ! idle; }

    float process()
    {
        // slow VCO wander + per-hit detune, always running so free-run is cheap
        const float wan = wander.process (rng.next()) * wanderGain;
        const float cents = G.drift * (wan * 6.0f) + hitCents;
        const float base = P.pitchHz * std::exp2 (cents * (1.0f / 1200.0f));

        if (idle)
        {
            if (G.freeRun) { phase += base / sr; phase -= std::floor (phase); }
            return 0.0f;
        }

        const float gT = std::min (1.0f, 2.0f * (1.0f - P.balance));
        const float gN = std::min (1.0f, 2.0f * P.balance);
        float out = 0.0f;

        if (P.model == Model::UDS)
        {
            const float tRaw = toneEnv.tick();
            const float nRaw = noiseEnv.tick();
            const float sRaw = snapEnv.tick();
            const float ampTone  = toneAtk.process (tRaw);
            const float pitchEnv = pitchLag.process (tRaw);
            const float ampNoise = noiseAtk.process (nRaw);

            const float f = clampf (base + spaceToHz (P.space) * pitchEnv, 4.0f, 0.45f * sr);
            phase += f / sr; phase -= std::floor (phase);
            const float osc = oscSample (P.wave, phase, f / sr);

            const float lf = lfsr.tick ((double) P.spectrumHz / (double) sr);
            const float bp = noiseBp.process (lf).bp * bpGain;

            // snap = raw noise burst + ringing resonator
            const float y = ra1 * ry1 + ra2 * ry2 + rb * rImpulse;
            rImpulse = 0.0f; ry2 = ry1; ry1 = y;
            const float snapSig = (lf * sRaw * 0.5f + y * 0.9f) * P.snap;

            out = (osc * ampTone * gT * 0.9f + bp * ampNoise * gN + snapSig) * P.level * kVoiceTrim;

            idle = ! (toneEnv.x > 0.0f || noiseEnv.x > 0.0f || snapEnv.x > 0.0f
                      || noiseAtk.z > 1e-4f || toneAtk.z > 1e-4f
                      || std::fabs (ry1) + std::fabs (ry2) > 1e-5f);
        }
        else
        {
            const float tRaw = toneEnv.tick();
            const float amp  = noiseAtk.process (tRaw);          // attack-shaped amplitude

            const float f = clampf (base + spaceToHz (P.space) * tRaw, 4.0f, 0.45f * sr);
            phase += f / sr; phase -= std::floor (phase);
            const float osc = oscSample (P.wave, phase, f / sr);
            const float nz  = rng.next();

            const float mix = osc * gT * 0.9f + nz * gN * 0.8f;
            elsFilter.set (P.timbreHz * std::exp2 (1.5f * amp), kElsQ, sr);
            const float lp = elsFilter.process (mix).lp;
            out = lp * amp * P.level * kVoiceTrim;

            idle = ! (toneEnv.x > 0.0f || noiseAtk.z > 1e-4f);
        }
        if (idle) { noiseBp.reset(); elsFilter.reset(); }
        return out;
    }

private:
    static constexpr float kVoiceTrim = 0.55f;   // leaves headroom: a full-velocity hit peaks well under 0 dBFS
    static constexpr float kBpQ  = 2.5f;
    static constexpr float kElsQ = 1.3f;

    float sr = 48000.0f;
    ChannelParams P; Globals G;
    Rng rng; Lfsr lfsr;
    RcEnv toneEnv, noiseEnv, snapEnv;
    OnePole pitchLag, noiseAtk, toneAtk, wander;
    Svf noiseBp, elsFilter;
    float bpGain = 1.0f, lastTimbre = -1.0f, wanderGain = 1.0f, hitCents = 0.0f;
    float phase = 0.0f;
    float ra1 = 0, ra2 = 0, rb = 0, ry1 = 0, ry2 = 0, rImpulse = 0;
    bool idle = true;
};

//==============================================================================
// Output stage: inverting-mixer opamp with an (optional) antiparallel-diode clipper
// in its feedback, like sx107's overdrive mod. drive 0..1.
inline float outputStage (float x, float drive)
{
    const float g = 0.05f + 7.95f * drive * drive;
    return std::asinh (g * x) / std::asinh (g);
}

constexpr int kNumChannels = 4;
inline int defaultNote (int ch) { static const int n[4] = { 36, 38, 45, 42 }; return n[ch & 3]; }

inline ChannelParams defaultChannel (int ch)
{
    ChannelParams p;
    switch (ch & 3)
    {
        case 0: // UDS kick
            p.model = Model::UDS; p.wave = Wave::Triangle; p.sens = 1.2f;
            p.pitchHz = 52.0f; p.space = 0.32f; p.pAtkMs = 0.1f; p.tDecayMs = 400.0f;
            p.spectrumHz = 3000.0f; p.timbreHz = 700.0f; p.nAtkMs = 0.5f; p.nDecayMs = 40.0f;
            p.balance = 0.12f; p.snap = 0.35f; p.snapTuneHz = 1500.0f; p.level = 0.9f; break;
        case 1: // UDS snare
            p.model = Model::UDS; p.wave = Wave::Triangle; p.sens = 1.2f;
            p.pitchHz = 190.0f; p.space = 0.25f; p.pAtkMs = 0.1f; p.tDecayMs = 160.0f;
            p.spectrumHz = 24000.0f; p.timbreHz = 3200.0f; p.nAtkMs = 0.3f; p.nDecayMs = 220.0f;
            p.balance = 0.62f; p.snap = 0.5f; p.snapTuneHz = 2400.0f; p.level = 0.85f; break;
        case 2: // Elsita tom
            p.model = Model::Elsita; p.wave = Wave::Saw; p.sens = 1.2f;
            p.pitchHz = 110.0f; p.space = 0.30f; p.tDecayMs = 380.0f; p.timbreHz = 1800.0f;
            p.nAtkMs = 0.3f; p.balance = 0.08f; p.level = 0.85f; break;
        default: // Elsita hat
            p.model = Model::Elsita; p.wave = Wave::Pulse; p.sens = 1.2f;
            p.pitchHz = 520.0f; p.space = 0.05f; p.tDecayMs = 70.0f; p.timbreHz = 5000.0f;
            p.nAtkMs = 0.2f; p.balance = 0.9f; p.level = 0.9f; break;
    }
    return p;
}

} // namespace uds
