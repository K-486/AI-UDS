#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "Engine/UDSEngine.h"

class UDSProcessor : public juce::AudioProcessor
{
public:
    UDSProcessor();
    ~UDSProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout&) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    using AudioProcessor::processBlock;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "UDS-4 Drum Synth"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 6.5; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    static juce::String pid (int channel, const char* name)
    {
        return "c" + juce::String (channel + 1) + "_" + name;
    }

    juce::AudioProcessorValueTreeState apvts;

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    uds::ChannelParams readParams (int channel) const;

    struct ChannelPtrs
    {
        std::atomic<float> *model, *wave, *note, *sens, *pitch, *pAtk, *tDecay, *space, *spectrum,
                           *timbre, *nAtk, *nDecay, *balance, *snap, *snapTune, *level;
    };
    ChannelPtrs ptrs[uds::kNumChannels] {};
    std::atomic<float> *pDrift = nullptr, *pFree = nullptr, *pMaster = nullptr, *pDrive = nullptr;
    uds::Channel channels[uds::kNumChannels];

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (UDSProcessor)
};
