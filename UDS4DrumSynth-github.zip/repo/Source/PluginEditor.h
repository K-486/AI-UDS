#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"

//==============================================================================
class PanelLookAndFeel : public juce::LookAndFeel_V4
{
public:
    PanelLookAndFeel();
    void drawRotarySlider (juce::Graphics&, int x, int y, int w, int h, float pos,
                           float startAngle, float endAngle, juce::Slider&) override;
};

//==============================================================================
// One channel: header (model / wave / note) + 13 knobs. Knobs the selected model
// doesn't use are dimmed and disabled; labels switch between UDS and Elsita naming.
class ChannelStrip : public juce::Component
{
public:
    ChannelStrip (UDSProcessor&, int channelIndex);
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void refreshModel();

    struct Knob
    {
        juce::Slider slider;
        std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attach;
        juce::Rectangle<int> labelArea;
        juce::String label, cyr;
    };

    UDSProcessor& proc;
    const int index;
    bool isElsita = false;

    juce::ComboBox modelBox, waveBox;
    juce::Slider noteSlider;
    std::vector<std::unique_ptr<Knob>> knobs;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> modelAttach, waveAttach;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> noteAttach;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ChannelStrip)
};

//==============================================================================
class UDSEditor : public juce::AudioProcessorEditor
{
public:
    explicit UDSEditor (UDSProcessor&);
    ~UDSEditor() override;
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    PanelLookAndFeel laf;
    std::vector<std::unique_ptr<ChannelStrip>> strips;

    juce::Slider driftSlider, driveSlider, masterSlider;
    juce::ToggleButton freeRunButton { "Free-running VCO" };
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> driftA, driveA, masterA;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> freeA;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (UDSEditor)
};
