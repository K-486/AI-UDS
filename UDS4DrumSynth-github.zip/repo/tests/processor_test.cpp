// Headless test of the real JUCE processor: MIDI mapping, model switching, all-notes-off, state round-trip.
#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"
#include <cstdio>

static int failures = 0;
#define CHECK(cond, msg) do { if (! (cond)) { ++failures; printf ("FAIL: %s\n", msg); } else printf ("ok:   %s\n", msg); } while (0)

struct Result { float peak = 0; int firstNonZero = -1; };

static Result run (UDSProcessor& p, int note, int totalSamples = 48000, int noteAt = 10, bool allOffAt = false)
{
    Result r; const int block = 512; int pos = 0;
    juce::AudioBuffer<float> buf (2, block);
    while (pos < totalSamples)
    {
        juce::MidiBuffer midi;
        if (note >= 0 && pos == 0) midi.addEvent (juce::MidiMessage::noteOn (1, note, (juce::uint8) 127), noteAt);
        if (allOffAt && pos == 512 * 4) midi.addEvent (juce::MidiMessage::allNotesOff (1), 0);
        p.processBlock (buf, midi);
        for (int i = 0; i < block; ++i)
        {
            const float v = std::fabs (buf.getSample (0, i));
            if (v > 1e-6f && r.firstNonZero < 0) r.firstNonZero = pos + i;
            r.peak = std::max (r.peak, v);
            if (std::fabs (buf.getSample (1, i) - buf.getSample (0, i)) > 1e-9f) { printf ("L/R mismatch\n"); ++failures; }
        }
        pos += block;
    }
    return r;
}

int main()
{
    UDSProcessor p;
    p.setPlayConfigDetails (0, 2, 48000.0, 512);
    p.prepareToPlay (48000.0, 512);
    printf ("parameters: %d\n", (int) p.getParameters().size());

    float peaks[4];
    const int notes[4] = { 36, 38, 45, 42 };
    for (int c = 0; c < 4; ++c)
    {
        p.prepareToPlay (48000.0, 512);
        auto r = run (p, notes[c]);
        peaks[c] = r.peak;
        char m[96]; snprintf (m, sizeof m, "ch%d note %d sounds (peak %.3f, first sample %d, expected >= 10)", c + 1, notes[c], r.peak, r.firstNonZero);
        CHECK (r.peak > 0.1f && r.peak < 1.2f && r.firstNonZero >= 10, m);
    }
    p.prepareToPlay (48000.0, 512);
    CHECK (run (p, 60).peak == 0.0f, "unmapped note 60 is silent");
    p.prepareToPlay (48000.0, 512);
    CHECK (run (p, -1).peak == 0.0f, "no MIDI -> silence");

    // model switch changes the sound of channel 1
    p.prepareToPlay (48000.0, 512);
    p.apvts.getParameter ("c1_model")->setValueNotifyingHost (1.0f);
    auto sw = run (p, 36);
    CHECK (sw.peak > 0.05f && std::fabs (sw.peak - peaks[0]) > 1e-4f, "switching ch1 to Elsita model changes output");
    p.apvts.getParameter ("c1_model")->setValueNotifyingHost (0.0f);

    // remap note
    p.apvts.getParameter ("c1_note")->setValueNotifyingHost (p.apvts.getParameter ("c1_note")->convertTo0to1 (60.0f));
    p.prepareToPlay (48000.0, 512);
    CHECK (run (p, 60).peak > 0.1f, "ch1 remapped to note 60 responds to note 60");
    p.prepareToPlay (48000.0, 512);
    CHECK (run (p, 36).peak < 1e-6f, "ch1 no longer responds to note 36");
    p.apvts.getParameter ("c1_note")->setValueNotifyingHost (p.apvts.getParameter ("c1_note")->convertTo0to1 (36.0f));

    // all notes off silences a ringing channel (kick rings ~400 ms, test cuts at block 4 = ~43 ms)
    p.prepareToPlay (48000.0, 512);
    {
        Result r; juce::AudioBuffer<float> buf (2, 512); float tail = 0;
        for (int b = 0; b < 20; ++b)
        {
            juce::MidiBuffer midi;
            if (b == 0) midi.addEvent (juce::MidiMessage::noteOn (1, 36, (juce::uint8) 127), 0);
            if (b == 4) midi.addEvent (juce::MidiMessage::allNotesOff (1), 0);
            p.processBlock (buf, midi);
            if (b >= 5) for (int i = 0; i < 512; ++i) tail = std::max (tail, std::fabs (buf.getSample (0, i)));
        }
        CHECK (tail < 1e-6f, "All Notes Off silences ringing voices");
    }

    // velocity: soft hit quieter than hard hit
    {
        p.prepareToPlay (48000.0, 512);
        juce::AudioBuffer<float> buf (2, 512); float pk = 0;
        for (int b = 0; b < 8; ++b) { juce::MidiBuffer m; if (b == 0) m.addEvent (juce::MidiMessage::noteOn (1, 36, (juce::uint8) 30), 0); p.processBlock (buf, m); pk = std::max (pk, buf.getMagnitude (0, 512)); }
        CHECK (pk > 0.0f && pk < peaks[0] * 0.5f, "velocity 30 is much quieter than velocity 127");
    }

    // state round trip
    {
        p.apvts.getParameter ("c2_pitch")->setValueNotifyingHost (p.apvts.getParameter ("c2_pitch")->convertTo0to1 (333.0f));
        juce::MemoryBlock mb; p.getStateInformation (mb);
        p.apvts.getParameter ("c2_pitch")->setValueNotifyingHost (p.apvts.getParameter ("c2_pitch")->convertTo0to1 (50.0f));
        p.setStateInformation (mb.getData(), (int) mb.getSize());
        const float v = p.apvts.getRawParameterValue ("c2_pitch")->load();
        char m[96]; snprintf (m, sizeof m, "state round-trip restores c2_pitch (%.1f, expected ~333)", v);
        CHECK (std::fabs (v - 333.0f) < 1.0f, m);
    }
    printf ("\n%s (%d failures)\n", failures ? "TESTS FAILED" : "ALL PROCESSOR TESTS PASSED", failures);
    return failures ? 1 : 0;
}
