#include "../Source/Engine/UDSEngine.h"
#include <chrono>
#include <cstdio>
#include <cstring>
#include <vector>
#include <string>
using namespace uds;

static void writeWav (const std::string& path, const std::vector<float>& x, int sr)
{
    FILE* f = fopen (path.c_str(), "wb");
    uint32_t dataBytes = (uint32_t) x.size() * 2, chunk = 36 + dataBytes, fmtLen = 16, rate = sr, byteRate = sr * 2;
    uint16_t pcm = 1, ch = 1, align = 2, bits = 16;
    fwrite ("RIFF", 1, 4, f); fwrite (&chunk, 4, 1, f); fwrite ("WAVEfmt ", 1, 8, f);
    fwrite (&fmtLen, 4, 1, f); fwrite (&pcm, 2, 1, f); fwrite (&ch, 2, 1, f); fwrite (&rate, 4, 1, f);
    fwrite (&byteRate, 4, 1, f); fwrite (&align, 2, 1, f); fwrite (&bits, 2, 1, f);
    fwrite ("data", 1, 4, f); fwrite (&dataBytes, 4, 1, f);
    for (float v : x) { int16_t s = (int16_t) std::lround (clampf (v, -1.f, 1.f) * 32767.f); fwrite (&s, 2, 1, f); }
    fclose (f);
}

static std::vector<float> renderHit (int chIdx, float vel, float seconds, int sr, ChannelParams p, Globals g)
{
    Channel c; c.prepare (sr, 7u + chIdx);
    c.setParams (p, g);
    std::vector<float> out ((size_t) (seconds * sr));
    c.trigger (vel);
    for (auto& s : out) s = outputStage (c.process(), 0.0f);
    return out;
}

int main()
{
    const int sr = 48000;
    // 1) LFSR must be maximal length
    {
        Lfsr l; const uint32_t start = l.reg; uint32_t n = 0;
        do { l.step(); ++n; } while (l.reg != start && n < 600000);
        printf ("LFSR period = %u (expected %u)\n", n, (1u << 18) - 1);
    }
    // 2) default channels, full velocity
    Globals g; g.drift = 0.0f; g.freeRun = false;       // deterministic for measurement
    for (int c = 0; c < 4; ++c)
    {
        auto x = renderHit (c, 1.0f, 2.0f, sr, defaultChannel (c), g);
        double pk = 0, e100 = 0; int n100 = sr / 10; int lastLoud = 0; bool bad = false;
        for (size_t i = 0; i < x.size(); ++i) { pk = std::max (pk, (double) std::fabs (x[i])); if (! std::isfinite (x[i])) bad = true;
            if (i < (size_t) n100) e100 += x[i] * x[i];
            if (std::fabs (x[i]) > 0.001f) lastLoud = (int) i; }
        printf ("ch%d model=%d peak=%.3f rms(first100ms)=%.3f audible-until=%.0f ms nan=%d\n", c + 1, (int) defaultChannel (c).model, pk, std::sqrt (e100 / n100), 1000.0 * lastLoud / sr, bad);
        writeWav ("/home/claude/tests_out_ch" + std::to_string (c + 1) + ".wav", x, sr);
    }
    // 3) velocity behaviour on the UDS kick
    for (float v : { 0.25f, 0.6f, 1.0f })
    {
        auto x = renderHit (0, v, 2.0f, sr, defaultChannel (0), g);
        int last = 0; double pk = 0; for (size_t i = 0; i < x.size(); ++i) { pk = std::max (pk, (double) std::fabs (x[i])); if (std::fabs (x[i]) > 0.001f) last = (int) i; }
        printf ("kick vel=%.2f peak=%.3f audible-until=%.0f ms\n", v, pk, 1000.0 * last / sr);
        writeWav ("/home/claude/tests_out_kickvel" + std::to_string ((int) (v * 100)) + ".wav", x, sr);
    }
    // 4) pitch-env attack makes tom 'zaps' rise: long pAtk on a UDS tone
    { ChannelParams p = defaultChannel (0); p.pitchHz = 120; p.space = 0.5f; p.pAtkMs = 40; p.tDecayMs = 500; p.balance = 0;
      writeWav ("/home/claude/tests_out_zap.wav", renderHit (0, 1.0f, 1.0f, sr, p, g), sr); }
    // 5) noise 'spectrum' sweep: low clock = grainy/dark, high = bright
    for (float clk : { 500.f, 4000.f, 40000.f })
    { ChannelParams p = defaultChannel (1); p.balance = 1.0f; p.snap = 0; p.timbreHz = 4000; p.spectrumHz = clk;
      writeWav ("/home/claude/tests_out_noise" + std::to_string ((int) clk) + ".wav", renderHit (1, 1.0f, 0.6f, sr, p, g), sr); }
    // 6) retrigger-while-loud: peak detector ignores a weaker hit on a loud tail
    {
        Channel c; c.prepare (sr, 3); c.setParams (defaultChannel (0), g);
        std::vector<float> x ((size_t) (1.0 * sr));
        c.trigger (1.0f);
        for (size_t i = 0; i < x.size(); ++i) { if (i == (size_t) (0.05 * sr)) c.trigger (0.3f); x[i] = c.process(); }
        writeWav ("/home/claude/tests_out_retrig.wav", x, sr);
    }
    // 7) demo loop: 2 bars @ 118 bpm, 16ths, all four channels, drift + free-run ON
    {
        Globals gd; gd.drift = 0.35f; gd.freeRun = true;
        const double bpm = 118.0; const int step = (int) (sr * 60.0 / bpm / 4.0); const int steps = 32;
        std::vector<float> out ((size_t) (steps * step + sr * 2), 0.0f);
        Channel ch[4]; for (int i = 0; i < 4; ++i) { ch[i].prepare (sr, 11u + i); ch[i].setParams (defaultChannel (i), gd); }
        // pattern: kick, snare, tom, hat   (step index -> velocity)
        const float K[16] = {1,0,0,0, 0,0,0.7f,0, 1,0,0.6f,0, 0,0,0,0};
        const float S[16] = {0,0,0,0, 1,0,0,0.4f, 0,0,0,0, 1,0,0.5f,0};
        const float T[16] = {0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0.8f,0.6f};
        const float H[16] = {0.8f,0.35f,0.6f,0.35f, 0.8f,0.35f,0.6f,0.45f, 0.8f,0.35f,0.6f,0.35f, 0.8f,0.35f,0.7f,0.5f};
        const float* pat[4] = { K, S, T, H };
        for (int n = 0; n < (int) out.size(); ++n)
        {
            if (n % step == 0 && n / step < steps)
                for (int i = 0; i < 4; ++i) { float v = pat[i][(n / step) % 16]; if (v > 0) ch[i].trigger (v); }
            float s = 0; for (int i = 0; i < 4; ++i) s += ch[i].process();
            out[(size_t) n] = outputStage (s * 0.7f, 0.15f);
        }
        writeWav ("/home/claude/tests_out_demo.wav", out, sr);
    }

    // 8) fuzz: random extreme parameters at several sample rates must stay finite and bounded
    {
        Rng r; r.seed (99); int bad = 0; float worst = 0.0f;
        auto u = [&] (float lo, float hi) { return lo + (hi - lo) * (0.5f * (r.next() + 1.0f)); };
        auto lg = [&] (float lo, float hi) { return lo * std::pow (hi / lo, 0.5f * (r.next() + 1.0f)); };
        for (int rate : { 22050, 44100, 48000, 96000, 192000 })
            for (int trial = 0; trial < 150; ++trial)
            {
                ChannelParams p; p.model = (r.next() > 0) ? Model::UDS : Model::Elsita;
                p.wave = (Wave) (int) u (0, 2.99f); p.sens = lg (0.25f, 4.0f); p.pitchHz = lg (20, 2000);
                p.pAtkMs = lg (0.1f, 150); p.tDecayMs = lg (5, 6000); p.space = u (0, 1); p.spectrumHz = lg (200, 60000);
                p.timbreHz = lg (120, 10000); p.nAtkMs = lg (0.1f, 200); p.nDecayMs = lg (5, 6000); p.balance = u (0, 1);
                p.snap = u (0, 1); p.snapTuneHz = lg (600, 6000); p.level = u (0, 1);
                Globals gg; gg.drift = u (0, 1); gg.freeRun = r.next() > 0;
                Channel c; c.prepare (rate, 5u + trial); c.setParams (p, gg);
                for (int n = 0; n < rate; ++n)
                {
                    if (n % (rate / 8) == 0) c.trigger (u (0.05f, 1.0f));
                    float y = c.process();
                    if (! std::isfinite (y)) ++bad; worst = std::max (worst, std::fabs (y));
                }
            }
        printf ("fuzz: non-finite=%d worst |sample| = %.3f\n", bad, worst);
    }
    // 9) CPU: 4 active channels, 10 s of audio @48k
    {
        Channel c[4]; Globals gg; for (int i = 0; i < 4; ++i) { c[i].prepare (48000, i); c[i].setParams (defaultChannel (i), gg); }
        volatile float sink = 0; auto t0 = std::chrono::steady_clock::now();
        for (int n = 0; n < 480000; ++n) { if (n % 6000 == 0) for (auto& ch : c) ch.trigger (0.9f); float s = 0; for (auto& ch : c) s += ch.process(); sink = s; }
        double secs = std::chrono::duration<double> (std::chrono::steady_clock::now() - t0).count();
        printf ("CPU: 10 s of 4-channel audio rendered in %.3f s  (%.1fx realtime, ~%.2f%% of one core)\n", secs, 10.0 / secs, 100.0 * secs / 10.0);
    }
    return 0;
}
