# UDS-4 Drum Synth

[![Build](../../actions/workflows/build.yml/badge.svg)](../../actions/workflows/build.yml)

A JUCE drum synth (VST3 / AU / Standalone) inspired by the **Lell UDS** and the **RMIF Elsita**.
Four MIDI-triggered channels; each channel can be a Lell-UDS voice or an Elsita voice.
Not affiliated with either maker. No samples. Everything is synthesised.

## Build
    cmake -B build -DCMAKE_BUILD_TYPE=Release            # downloads JUCE 8.0.8
    # or: cmake -B build -DJUCE_PATH=/path/to/your/JUCE
    cmake --build build --config Release

Linux needs the usual JUCE dev packages (ALSA, freetype, fontconfig, X11 libs, GL).
Plugins land under `build/UDS4DrumSynth_artefacts/`.

Engine-only test (no JUCE): `g++ -std=c++17 -O2 tests/render_test.cpp -o render_test && ./render_test`
renders WAVs and prints checks (LFSR period, decay times, fuzz test, CPU).

## MIDI
Default notes: ch1 C1/36, ch2 D1/38, ch3 A1/45, ch4 F#1/42. Every note is remappable.
Velocity is the pad hit strength; it changes level, pitch-sweep depth AND decay length.

## What is modelled (Lell UDS channels), and where it comes from
Source: sx107's schematic teardown, hackaday.io/project/171677 (the Lell UDS service schematics are on ruskeys.net).

| Hardware block | In this plugin |
|---|---|
| Pad -> preamp -> positive-peak detector, diode charge + RC release | `RcEnv`. Every envelope follows the hit. Soft hits are quieter *and shorter*. A weak hit on a loud tail does nothing (diode). **Sens** = gain before the detector, so high Sens squashes velocity. |
| Tone VCO: relaxation oscillator, triangle, control linear in Hz | Triangle osc, `freq = Tone + Space^2*1200 Hz * pitchEnv`. Linear in Hz, not 1V/oct. Free-running between hits (toggle). |
| Pitch envelope shares the tone release; own attack RC | **Tone rel** sets both. **Tone atk** only delays the pitch rise (that makes the "zaps"). Amplitude attack is ~instant, as on the board. |
| Noise: shift register + XOR (xorshift) clocked by an astable | 18-bit maximal-length LFSR. **Spectrum** = clock rate. Low clock = stepped, grainy, quieter. |
| Noise bandpass ("timbre") then VCA with own attack/release | RBJ-style TPT bandpass, Q 2.5, then VCA with **Noise atk / Noise rel**. |
| Snap: raw noise burst + super-resonant filter ringing a sine | Short raw-noise burst + 2-pole resonator (~28 ms ring). **Snap tune** exposes what is a trimmer on the board. |
| Balance, level, inverting mixer | **Balance**, **Level**, output stage with optional diode-style clip (**Drive**, after sx107's mod #4). |
| VCO drift | **Drift**: slow wander + per-hit detune. |

## Elsita channels
Built from the documented panel only (sens, tone, attack, decay, filter, tone/noise, level) plus the
"A/B/A/B" character reports. The schematic scans were not readable, so this is a conventional
osc + noise -> resonant lowpass -> VCA voice with one shared envelope. Treat it as inspired-by, not measured.
Filter envelope amount, filter Q, white noise source and the saw/pulse choice are my assumptions.

## Known gaps
* The UDS decay shape (RC toward a floor below VCA cutoff) is inferred from the stated -9 V..7.5 V envelope range.
* Exact LFSR taps, bandpass Q, snap decay time and VCO range are guesses. The first thing to do with a real unit or recordings is tune these.
* No audio-trigger input (the originals triggered from pad audio). That would be an envelope-follower input stage.
* Mono output (the hardware mixes to one output).

## Audio examples
`audio_examples/` holds rendered one-shots and a demo loop from the engine (not recorded from hardware).

## Licence
No licence file is included yet: choose one before publishing.
JUCE is dual-licensed (AGPLv3 or a commercial licence). If you distribute a plugin built with JUCE under
the AGPL route, your plugin source must be released under AGPLv3 too. See https://juce.com/legal/juce-8-licence/

## Credits / sources
* sx107, "Soviet drum synth - Lell UDS" (hackaday.io/project/171677): schematic analysis the UDS voice is modelled on.
* ruskeys.net (Soviet synth museum): original manuals/schematics for the Lell UDS and RMIF Elsita.
